# Control Unit

![With built-in cruise control.](oredict:oc:materialCU)

Higher tier crafting item used in more advanced circuitry, such as [CPUs](cpu1.md).
