# Clavier

![AZERTY](oredict:oc:keyboard)

Un clavier est requis pour saisir du texte sur l'[écran](screen1.md), qu'ils existent physiquement dans le monde ou intégrés à un appareil comme un [robot](robot.md) ou une [tablette](../item/tablet.md).

Pour qu'un clavier fonctionne avec un [écran](screen1.md) dans le monde, il doit être placé à côté de l'[écran](screen1.md), orienté vers cet [écran](screen1.md), ou placé directement sur l'[écran](screen1.md) (au dessus ou sur l'une de ses faces). Vous pouvez savoir si un clavier est "connecté" à un [écran](screen1.md) si l'interface de l'[écran](screen1.md) s'ouvre en utilisant le clavier.
