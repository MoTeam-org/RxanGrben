# Grog

![Reflux?](oredict:oc:materialAcid)

Wird nur bei Hard-Mode-Rezepten verwenden. Es ist verwendet um [Leiterplatten](circuitBoard.md) zu ätzen, bevor sie zu [gedruckten Leiterplatten](printedCircuitBoard.md) werden.
