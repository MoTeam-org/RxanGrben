# Tankcontroller

![Flüssigrouting.](oredict:oc:tankControllerUpgrade)

Das Tankcontroller-Upgrade ist das [Inventarcontroller-Upgrade](inventoryControllerUpgrade.md) für Tanks. Es können detaillierte Informationen über Tanks abgefragt werden. 

Dieses Upgrade kann auch in [Adaptern](../block/adapter.md) installiert werden, womit angeschlossene [Computer](../general/computer.md) Informationen über anliegende Tanks abfragen kann.
