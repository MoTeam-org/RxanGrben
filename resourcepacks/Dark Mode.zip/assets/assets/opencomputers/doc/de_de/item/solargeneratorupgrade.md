# Solargenerator-Upgrade

![Is walking on sunshine.](oredict:oc:solarGeneratorUpgrade)

Das Solargenerator-Upgrade kann in Geräten wie [Robotern](../block/robot.md), [Drohnen](drone.md) und [Tablets](tablet.md) dazu verwendet werden, passiv Energie zu generieren. Es funktioniert nur, wenn das Gerät direktem Sonnenlicht ausgesetzt ist und keine Wetterereignisse stören.

Die Menge an generierter Energie ist relativ gering, aber es sollte genügen um die Zeit zwischen den Ladezyklen zu verringern oder sie sogar zu verhindern. 
