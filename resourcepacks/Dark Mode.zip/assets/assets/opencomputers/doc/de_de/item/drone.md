# Drohne

![Hat nichts mit der NSA zu tun..](item:OpenComputers:item@84)

Drohnen werden mit einem [Drohnengehäuse](droneCase1.md) in der [Elektronik-Werkbank](../block/assembler.md) gebaut. Sie sind entitybasierende [Roboter](../block/robot.md), allerdings ein bisschen günstiger und mit eingeschränkter Funktionalität. Sie können sich zudem weitaus schneller bewegen als [Roboter](../block/robot.md) und werden über ein Clientprogramm auf einem Computer gesteuert. Die Drohne benötigt ein konfiguriertes [EEPROM](eeprom.md) um Befehle zu empfangen oder selbst zu arbeiten.
