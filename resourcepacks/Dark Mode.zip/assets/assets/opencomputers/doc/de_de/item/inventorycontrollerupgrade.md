# Inventarbedienungs-Upgrade

![Ich bin unter Kontrolle.](oredict:oc:inventoryControllerUpgrade)

Das Inventarbedienungs-Upgrade ermöglicht erweiterte Inventarinteraktionen für [Roboter](../block/robot.md) und [Drohnen](drone.md). Es erlaubt es dem Gerät explizit einzelne Slots in externen Inventaren zu verwenden. Es erlaubt es dem Gerät zudem detaillierte Informationen über seine Itemstacks zu lesen. Zuletzt stellt es Robotern eine Möglichkeit zur Verfügung, das Werkzeug ohne Hilfe zu wechseln.

Dieses Upgrade kann zudem in [Adaptern](../block/adapter.md) platziert werden, wo es ähnliche Inspektionsmethoden auf angrenzende Inventare ermöglicht. Allerdings können keine Items aus oder in das Inventar geschoben werden; das geht bei Robotern und Drohnen.
