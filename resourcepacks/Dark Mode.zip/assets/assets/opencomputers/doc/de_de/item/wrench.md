# Schraubenziehschlüssel

![In der Schweiz gemacht.](oredict:oc:wrench)

Wie fast jede andere Technologie-Modifikation hat OpenComputer seine eigene Version eines Schraubenschlüssels. In diesem Fall ist es ein Schraubendreher-Schraubenschlüssel-Hybdrid, das unglaublich merkwürdig aussieht. Damit können die meisten Blöcke gedreht werden und ist mit den meisten Mods kompatibel.
