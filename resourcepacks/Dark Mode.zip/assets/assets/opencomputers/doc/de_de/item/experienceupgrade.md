# Erfahrungs-Upgrade

![Kaum sinnvoll, sehr cool.](oredict:oc:experienceUpgrade)

Das Erfahrungs-Upgrade ist ein sehr spezielles Upgrade, da es [Robotern](../block/robot.md) und [Drohnen](drone.md) ermöglicht, Erfahrung zu sammeln. Ein einziges Upgrade kann bis zu 30 Level speichern und ermöglicht damit kleinere Boni, wie schnellere Ausführung oder erhöhte Energiespeicherkapazität.

[Roboter](../block/robot.md) ab Level 10 bekommen eine goldene Färbung, ab Level 20 wechselt die Färbung in einen diamantenen Teint.

Die tatsächliche Erfahrung wird im Upgrade gespeichert, was bedeutet dass die Erfahrung zu anderen Geräten verschoben werden kann.
