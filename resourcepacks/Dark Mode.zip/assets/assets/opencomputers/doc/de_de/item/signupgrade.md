# Schilder-I/O

![Sagt mehr als tausend Worte.](oredict:oc:signUpgrade)

Dieses Upgrade ermöglicht es Geräten mit Schildern in der Welt zu interagieren. Es erlaubt das Lesen von Schildern sowie das Ändern des Schildes (wenn möglich).
