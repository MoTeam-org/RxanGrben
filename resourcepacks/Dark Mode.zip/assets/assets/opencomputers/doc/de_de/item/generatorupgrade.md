# Generator-Upgrade

![Generator X.](oredict:oc:generatorUpgrade)

Das Generator-Upgrade ermöglicht es Geräten sich im Betrieb neu aufzuladen. Zurzeit werden nur trockene Energiequellen (wie Kohle) unterstützt. Es hat ein internes Inventar welches ein Stack an Energiequellen halten kann. Überflüssige Energiequellen können über die Komponenten-API entfernt werden. Ein Upgrade von einem Roboter zu entfernen führt dazu, dass der Inhalt in die Welt geworfen wird.

Die Effizienz der Generatoren ist niedriger als die von Generatoren anderer Mods. [Ladegeräte](../block/charger.md) sind effizienter.
