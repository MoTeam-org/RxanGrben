# Navigations-Upgrade

![Ich habe mich verirrt. Schon. Wieder.](oredict:oc:navigationUpgrade)

Das Navigation-Upgrade stellt Informationen über den Standort und zur Orientierung bereit. Die Koordinaten, die das Upgrade zur Verfügung stellt sind relativ zum Zentrum der Karte, die zum Anfertigen des Upgrades verwendet wird. Die Reichweite des Upgrades basiert auf die Größe dieser Karte.

Die Karte in einem Navigation-Upgrade kann geändert werden, indem es mit einer neuen Karte in eine Werkbank gelegt wird. Die alte Karte wird dem Spieler zurückgegeben.

Dieses Update ist weitaus nützlicher in Kombination mit [Wegpunkten](../block/waypoint.md).
