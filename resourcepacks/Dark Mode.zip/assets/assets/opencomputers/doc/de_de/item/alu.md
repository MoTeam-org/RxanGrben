# Arithmetic Logic Unit

![Ich of logiks !](oredict:oc:materialALU)

Wird für rechnende Komponenten wie [CPUs](cpu1.md) und [Grafikkarten](graphicsCard1.md) benötigt.
