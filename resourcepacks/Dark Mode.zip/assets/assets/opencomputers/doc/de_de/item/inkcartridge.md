# Tintenkartusche

![Regenbogenfarbig.](oredict:oc:inkCartridge)

Tintenkartuschen sind nützlich um den Farbbuffer von [3D-Druckern·](../block/printer.md) zu füllen. Es ist auch möglich sie mit Farbmitteln direkt zu färben, das ist aber ineffizient. Am besten kaufen Sie noch heute die echten OC Tintenfarben (TM) heute! (Disclaimer: Unter Umständen könnten sie mehr als der Drucker selbst kosten.)
