# Weltsensorkarte

![Um dort hin zu gehen...](oredict:oc:worldSensorCard)

Die Weltsensorkarte ermöglicht es Informationen über die Atmosphäre und Gravitation von verschiedenen Planeten in GalactiCraft zu lesen. Das kann für [Roboter](../block/robot.md) oder [Drohnen](drone.md) im Weltraum nützlich sein.
