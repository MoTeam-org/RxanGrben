# Adapter

![Nun mit 100% mehr Alles!](oredict:oc:adapter)

Der Adapter ermöglicht es [Computern](../general/computer.md) mit Vanilla-Minecraft-Blöcken oder Blöcken von anderen Mods zu interagieren. Unterstützte Blöcke neben dem Adapter werden als Komponenten des Computers aufgelistet.

Zudem stellt der Adapter einige Slots für einige Updates bereit. Zum Beispiel das [Inventarkontroll-Upgrade](../item/inventoryControllerUpgrade.md), welches Computern die Möglichkeit gibt, mehr Informationen über ein angeschlossenes Inventar anzufragen. Ähnliches ist auch möglich, wenn das Upgade in einem Gerät (wie einem [Roboter](robot.md) oder einer [Drohne](../item/drone.md) installiert ist. Das [Tank-Kontrollupgrade](../item/tankControllerUpgrade.md) bietet dieselben Funktionen für Flüssigkeiten in Tanks.
