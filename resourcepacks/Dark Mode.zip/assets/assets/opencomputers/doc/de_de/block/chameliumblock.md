# Chamälium-Block

![So... nichtssagend...](oredict:oc:chameliumBlock)

Einige Stücke [Chamälium](../item/chamelium.md) können kombiniert werden, um einen dekorativen Monochrom-Block zu schaffen. Chamäliumblöcke können mit einer der 16 Minecraft-Farben gefärbt werden.

Der Chamäliumblock kann als Textur in einem [3D-Drucker](print.md) verwendet werden, wodurch das Gedruckte weiß wird.
